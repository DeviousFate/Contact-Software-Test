package appointmentPKG;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppointmentService {
    private List<Appointment> appointmentList = new ArrayList<>();

    public void addAppointment(String appointmentId, Date appointmentDate, String description) {
        for (Appointment appointment : appointmentList) {
            if (appointment.getAppointmentId().equals(appointmentId)) {
                throw new IllegalArgumentException("Appointment ID must be unique.");
            }
        }
        appointmentList.add(new Appointment(appointmentId, appointmentDate, description));
    }

    public void deleteAppointment(String appointmentId) {
        for (int i = 0; i < appointmentList.size(); i++) {
            if (appointmentList.get(i).getAppointmentId().equals(appointmentId)) {
                appointmentList.remove(i);
                return;
            }
        }
        throw new IllegalArgumentException("Appointment ID not found.");
    }

    public List<Appointment> getAppointments() {
        return appointmentList;
    }
}