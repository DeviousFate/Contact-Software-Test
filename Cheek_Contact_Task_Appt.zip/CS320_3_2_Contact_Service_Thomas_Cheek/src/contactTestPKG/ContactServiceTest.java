
package contactTestPKG;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import contactPKG.Contact;
import contactPKG.ContactService;

import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)


public class ContactServiceTest {
	
		@Test
		@DisplayName("Test to Update First Name.")
		@Order(1)
		
		void testUpdateFirstName() {
			ContactService service = new ContactService();
			service.addContact("Mr.", "Thomas", "1236540987", "123 ABC Street");
			service.updatefirstName("Doug", "0");
			service.displayContactList();
			assertEquals("Jim", service.getContact("0").getfirstName(), "First name was not updated.");
		}

		@Test
		@DisplayName("Test to Update Last Name.")
		@Order(2)
		void testUpdateLastName() {
			ContactService service = new ContactService();
			service.addContact("Mr.", "Thomas", "1236540987", "123 ABC Street");
			service.updatelastName("Dimmadome", "2");
			service.displayContactList();
			assertEquals("Ruben", service.getContact("2").getlastName(), "Last name was not updated.");
		}

		@Test
		@DisplayName("Test to update phone number.")
		@Order(3)
		void testUpdatePhoneNumber() {
			ContactService service = new ContactService();
			service.addContact("Mr.", "James", "1236540987", "123 ABC Street");
			service.updatephone("9876543210", "4");
			service.displayContactList();
			assertEquals("9876543210", service.getContact("4").getphone(), "Phone number was not updated.");
		}

		@Test
		@DisplayName("Test to update address.")
		@Order(4)
		void testUpdateAddress() {
			ContactService service = new ContactService();
			service.addContact("Mr.", "Thomas", "1236540987", "123 ABC Street");
			service.updateaddress("321 Overthere St", "4");
			service.displayContactList();
			assertEquals("321 Overthere St", service.getContact("4").getaddress(), "Address was not updated.");
		}

		@Test
		@DisplayName("Test to ensure that service correctly deletes contacts.")
		@Order(5)
		void testDeleteContact() {
			ContactService service = new ContactService();
			service.addContact("Mr.", "Thomas", "1236540987", "123 ABC Street");
			service.deleteContact("5");
			// Ensure that the contactList is now empty by creating a new empty contactList to compare it with
			ArrayList<Contact> contactListEmpty = new ArrayList<Contact>();
			service.displayContactList();
			assertEquals(service.contactList, contactListEmpty, "The contact was not deleted.");
		}

		@Test
		@DisplayName("Test to ensure that service can add a contact.")
		@Order(6)
		void testAddContact() {
			ContactService service = new ContactService();
			service.addContact("Mr.", "Thomas", "1236540987", "123 ABC Street");
			service.displayContactList();
			assertNotNull(service.getContact("6"), "Contact was not added correctly.");
		}

	}