package school;

public class SchoolClass {
	
	private String name;
	private String id;
	
	public SchoolClass(String name, String id) {
		if(name == null || name.length()>10) { 
			throw new IllegalArgumentException("Invalid name");
		}
		if(id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid id");
		}
		
		this.name = name;
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getid() {
		return id;
	}

}
