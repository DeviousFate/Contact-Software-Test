package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import school.SchoolClass;

class SchoolClassTest {

	@Test
	void testSchoolClass() {
		SchoolClass schoolClass = new SchoolClass("Java 101", "12345");
		assertTrue(schoolClass.getName().equals("Java 101"));
		assertTrue(schoolClass.getid().equals("12345"));
	}

	@Test
	void testSchoolClassNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new SchoolClass("Java 102111", "12345");
		});
	}
	
	@Test
	void testSchoolClassNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new SchoolClass(null, "12345");
		});
	}
	
	@Test
	void testSchoolClassidTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new SchoolClass("Java 102", "12345647891");
		});
	}

}
