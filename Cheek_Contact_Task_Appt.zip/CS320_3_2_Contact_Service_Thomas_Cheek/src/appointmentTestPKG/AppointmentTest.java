package appointmentTestPKG;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import appointmentPKG.Appointment;
import java.util.Date;

public class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in future
        Appointment appointment = new Appointment("12345", futureDate, "Doctor's Visit");
        assertNotNull(appointment);
    }

    @Test
    void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Checkup"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Checkup"));
    }

    @Test
    void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in past
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", pastDate, "Checkup"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", null, "Checkup"));
    }

    @Test
    void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, "a".repeat(51)));
    }

    @Test
    void testUpdateDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("12345", futureDate, "Checkup");
        appointment.setDescription("Dentist Appointment");
        assertEquals("Dentist Appointment", appointment.getDescription());
    }
}
