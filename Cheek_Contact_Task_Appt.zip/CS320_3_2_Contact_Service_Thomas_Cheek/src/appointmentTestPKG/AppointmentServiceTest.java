package appointmentTestPKG;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import appointmentPKG.AppointmentService;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        service.addAppointment("12345", futureDate, "Doctor's Visit");
        assertEquals(1, service.getAppointments().size());
    }

    @Test
    void testAddDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        service.addAppointment("12345", futureDate, "Doctor's Visit");
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment("12345", futureDate, "Dentist Visit"));
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        service.addAppointment("12345", futureDate, "Doctor's Visit");
        service.deleteAppointment("12345");
        assertEquals(0, service.getAppointments().size());
    }

    @Test
    void testDeleteNonExistentAppointment() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("99999"));
    }
}
