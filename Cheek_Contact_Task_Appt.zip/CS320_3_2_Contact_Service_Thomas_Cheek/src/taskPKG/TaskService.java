package taskPKG;

import java.util.ArrayList;
import java.util.Iterator;

public class TaskService {
    public ArrayList<Task> taskList = new ArrayList<>();

    public void addTask(String name, String description) {
        Task newTask = new Task(name, description);
        taskList.add(newTask);
    }

    public void deleteTask(String taskId) {
        Iterator<Task> iterator = taskList.iterator();
        while (iterator.hasNext()) {
            Task task = iterator.next();
            if (task.getTaskId().equals(taskId)) {
                iterator.remove();
                return;
            }
        }
        throw new IllegalArgumentException("Task ID not found");
    }

    public void updateTaskName(String taskId, String newName) {
        for (Task task : taskList) {
            if (task.getTaskId().equals(taskId)) {
                task.setName(newName);
                return;
            }
        }
        throw new IllegalArgumentException("Task ID not found");
    }

    public void updateTaskDescription(String taskId, String newDescription) {
        for (Task task : taskList) {
            if (task.getTaskId().equals(taskId)) {
                task.setDescription(newDescription);
                return;
            }
        }
        throw new IllegalArgumentException("Task ID not found");
    }
}
