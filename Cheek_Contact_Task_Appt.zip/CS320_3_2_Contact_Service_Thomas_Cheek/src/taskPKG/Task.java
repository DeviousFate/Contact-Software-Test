package taskPKG;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
    private final String taskId;
    private String name;
    private String description;
    private static AtomicLong idGenerator = new AtomicLong();

    public Task(String name, String description) {
        this.taskId = String.valueOf(idGenerator.getAndIncrement());
        
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid Task ID");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid Task Name");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid Task Description");
        }
        
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid Task Name");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid Task Description");
        }
        this.description = description;
    }
}
