package contactPKG;

import java.util.ArrayList;

public class ContactService {

		public ArrayList<Contact> contactList = new ArrayList<Contact>();
		
		public void displayContactList() {
			for (int counter = 0; counter < contactList.size(); counter++) {
			System.out.println("\t Contact ID: " + contactList.get(counter).getContactId());
			System.out.println("\t First Name: " + contactList.get(counter).getfirstName());
			System.out.println("\t Last Name: " + contactList.get(counter).getlastName());
			System.out.println("\t Phone phone: " + contactList.get(counter).getphone());
			System.out.println("\t address: " + contactList.get(counter).getaddress() + "\n");
			}
		}

		// Adds a new contact using the Contact constructor, then assign the new contact to the list.
		public void addContact(String firstName, String lastName, String phone, String address) {
			// Create the new contact
			Contact contact = new Contact(firstName, lastName, phone, address);
			contactList.add(contact);

		}

		// Using Contact ID, return a contact object
		// If a matching Contact ID is not found, return a contact object with default values
		public Contact getContact(String ContactId) {
			Contact contact = new Contact(null, null, null, null);
			for (int counter = 0; counter < contactList.size(); counter++) {
				if (contactList.get(counter).getContactId().contentEquals(ContactId)) {
					contact = contactList.get(counter);
				}
			}
			return contact;
		}

		// Delete contact.
		// Use the ContactId to find the right contact to delete from the list
		// If we get to the end of the list without finding a match for ContactId report that to the console.
		// This method of searching for ContactId is the same for all update methods below.
		public void deleteContact(String ContactId) {
			for (int counter = 0; counter < contactList.size(); counter++) {
				if (contactList.get(counter).getContactId().equals(ContactId)) {
					contactList.remove(counter);
					break;
				}
				if (counter == contactList.size() - 1) {
					System.out.println("Contact ID: " + ContactId + " not found.");
				}
			}
		}

		// Update the first name.
		public void updatefirstName(String updatedString, String ContactId) {
			for (int counter = 0; counter < contactList.size(); counter++) {
				if (contactList.get(counter).getContactId().equals(ContactId)) {
					contactList.get(counter).setfirstName(updatedString);
					break;
				}
				if (counter == contactList.size() - 1) {
					System.out.println("Contact ID: " + ContactId + " not found.");
				}
			}
		}

		// Update the last name.
		public void updatelastName(String updatedString, String ContactId) {
			for (int counter = 0; counter < contactList.size(); counter++) {
				if (contactList.get(counter).getContactId().equals(ContactId)) {
					contactList.get(counter).setlastName(updatedString);
					break;
				}
				if (counter == contactList.size() - 1) {
					System.out.println("Contact ID: " + ContactId + " not found.");
				}
			}
		}

		// Update the phone.
		public void updatephone(String updatedString, String ContactId) {
			for (int counter = 0; counter < contactList.size(); counter++) {
				if (contactList.get(counter).getContactId().equals(ContactId)) {
					contactList.get(counter).setphone(updatedString);
					break;
				}
				if (counter == contactList.size() - 1) {
					System.out.println("Contact ID: " + ContactId + " not found.");
				}
			}
		}

		// Update the address.
		public void updateaddress(String updatedString, String ContactId) {
			for (int counter = 0; counter < contactList.size(); counter++) {
				if (contactList.get(counter).getContactId().equals(ContactId)) {
					contactList.get(counter).setaddress(updatedString);
					break;
				}
				if (counter == contactList.size() - 1) {
					System.out.println("Contact ID: " + ContactId + " not found.");
				}
			}
		}
	}