package contactPKG;

import java.util.concurrent.atomic.AtomicLong;

public class Contact {
		
		private final String ContactId;
		private String firstName;
		private String lastName;
		private String phone;
		private String address;
		private static AtomicLong idGenerator = new AtomicLong();

		
		public Contact(String firstName, String lastName, String phone, String address) {
			
			this.ContactId = String.valueOf(idGenerator.getAndIncrement());
			
			if(ContactId == null || ContactId.length()>10) { 
				throw new IllegalArgumentException("Invalid ContactId");
			}
			
			if(firstName == null || firstName.length()>10) { 
				throw new IllegalArgumentException("Invalid First Name");
			}
			
			if(lastName == null || lastName.length()>10) { 
				throw new IllegalArgumentException("Invalid Last Name");
			}
			
			if(phone == null || phone.length() != 10) {
				throw new IllegalArgumentException("Invalid Phone #");
			}
			
			if(address == null || phone.length() > 30) {
				throw new IllegalArgumentException("Invalid Address");
			}
			
			this.firstName = firstName;
			this.lastName = lastName;
			this.phone = phone;
			this.address = address;
		}


		//Data Getters
		public String getContactId() {
			return ContactId;
		}
		
		public String getfirstName() {
			return firstName;
		}
		
		public String getlastName() {
			return lastName;
		}
		
		public String getphone() {
			return phone;
		}
		
		public String getaddress() {
			return address;
		}
		
		
		// Data Setters
		public void setfirstName(String firstName) {
			if (firstName == null || firstName.isEmpty()) {
				this.firstName = "NULL";

			// If first name is longer than 10 characters, just grab the first 10 characters
			} else if (firstName.length() > 10) {
				this.firstName = firstName.substring(0, 10);
			} else {
				this.firstName = firstName;
			}
		}

		public void setlastName(String lastName) {
			if (lastName == null || lastName.isEmpty()) {
				this.lastName = "NULL";
			} else if (lastName.length() > 10) {
				this.lastName = lastName.substring(0, 10);
			} else {
				this.lastName = lastName;
			}
		}

		public void setphone(String number) {
			if (number == null || number.isEmpty() || number.length() != 10) {
				this.phone = "1234567890";
			} else {
				this.phone = number;
			}
		}

		public void setaddress(String address) {
			if (address == null || address.isEmpty()) {
				this.address = "NULL";
			} else if (address.length() > 30) {
				this.address = address.substring(0, 30);
			} else {
				this.address = address;
			}
		}

	}