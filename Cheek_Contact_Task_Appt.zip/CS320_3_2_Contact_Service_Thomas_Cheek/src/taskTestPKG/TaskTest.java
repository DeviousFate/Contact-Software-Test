package taskTestPKG;

import org.junit.jupiter.api.Test;
import taskPKG.Task;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("Sample Task", "This is a valid description.");
        assertNotNull(task.getTaskId());
        assertEquals("Sample Task", task.getName());
        assertEquals("This is a valid description.", task.getDescription());
    }

    @Test
    void testInvalidTaskName() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Valid description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("ThisNameIsWayTooLongForValidation", "Valid description"));
    }

    @Test
    void testInvalidTaskDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("Valid Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("Valid Name", "This description is way too long and exceeds the fifty-character limit."));
    }

    @Test
    void testUpdateTaskName() {
        Task task = new Task("Initial Name", "Initial Description");
        task.setName("Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test
    void testUpdateTaskDescription() {
        Task task = new Task("Initial Name", "Initial Description");
        task.setDescription("Updated Description");
        assertEquals("Updated Description", task.getDescription());
    }
}
