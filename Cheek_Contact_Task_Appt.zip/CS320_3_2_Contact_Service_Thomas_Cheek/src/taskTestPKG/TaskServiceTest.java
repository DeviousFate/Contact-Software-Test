package taskTestPKG;

import org.junit.jupiter.api.Test;
import taskPKG.TaskService;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        service.addTask("New Task", "A valid description");
        assertEquals(1, service.taskList.size());
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        service.addTask("Task to Delete", "Description");
        String taskId = service.taskList.get(0).getTaskId();
        service.deleteTask(taskId);
        assertEquals(0, service.taskList.size());
    }

    @Test
    void testUpdateTaskName() {
        TaskService service = new TaskService();
        service.addTask("Initial Name", "Description");
        String taskId = service.taskList.get(0).getTaskId();
        service.updateTaskName(taskId, "Updated Name");
        assertEquals("Updated Name", service.taskList.get(0).getName());
    }

    @Test
    void testUpdateTaskDescription() {
        TaskService service = new TaskService();
        service.addTask("Task", "Initial Description");
        String taskId = service.taskList.get(0).getTaskId();
        service.updateTaskDescription(taskId, "Updated Description");
        assertEquals("Updated Description", service.taskList.get(0).getDescription());
    }

    @Test
    void testDeleteNonExistentTask() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }
}